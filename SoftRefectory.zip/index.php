<?php 
session_start();
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no"/>
  <title>Login</title>

  <!-- CSS  -->
  <link rel="stylesheet" href="frameworks/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="css/estilos.css">
  <link rel="stylesheet" href="css/styles.css">
  <link rel="shortcut icon" href="images/logo.png">
</head>
<body>
    <div class="row">
        <div class="col-md-offset-10">
            <a href="creditos.php">Creditos</a>   
        </div>
    </div>
    <div class="row">
        <img src="images/logo.png" class="img-resposive img-center">
    </div>
    <div class="row">
        <div class="col-md-offset-5 col-xs-2">
            <form class="form-horizontal" role="form" method="post">
                <div class="form-group">
                    <label for="user">Usuario</label>
                    <input class="form-control2" type="text" id="user" name="user" placeholder="Introduce tu usuario"> 
                    <label for="password">Contraseña</label>
                    <input class="form-control2" type="password" id="password" name="password" placeholder="Introduce tu contraseña"><br>
                    <input type="submit" name="boton" id="boton" value="Entrar">
                    <a href="registro.php">Registrarse</a>
                    
                </div>
            </form>
        </div>
    </div>
</body>
</html>
<?php
include "conexion.php";
    if(isset($_POST['boton'])){
        $user=$_POST['user'];
        $password=$_POST['password'];
        $st = $conn->prepare("SELECT * FROM waiter WHERE user=? and password=?");
        $st->setFetchMode(PDO::FETCH_OBJ);
        $st->execute(array($user,$password));
        $num= $st->fetch();
        if(!isset($num->user)){
            $st = $conn->prepare("SELECT * FROM chef WHERE user=? and password=?");
            $st->setFetchMode(PDO::FETCH_OBJ);
            $st->execute(array($user,$password));
            $num= $st->fetch();
            if(!isset($num->user)){
                $st = $conn->prepare("SELECT * FROM cashier WHERE user=? and password=?");
                $st->setFetchMode(PDO::FETCH_OBJ);
                $st->execute(array($user,$password));
                $num= $st->fetch();
                if(!isset($num->user)){
                    echo "Usuario o contraseña incorrecta";
                }
                else{
                    $_SESSION['user']=$num;
                    header("Location: home.php?user=cajero");
                }
            }
            else{
                $_SESSION['user']=$num;
                 header("Location: home.php?user=chef");
            }
        }
        else{
            $_SESSION['user']=$num;
            header("Location: home.php?user=mesero");
        }
    }
?>